import { Component } from '@angular/core';

@Component({
    selector:'app-child'
})
export class ChildComponent{

}