import { Component } from '@angular/core';

@Component({
    selector:'app-parent',
    templateUrl:'./parent.component.html'
})
export class ParentComponent{
    public name:string="Harry Potter";
}